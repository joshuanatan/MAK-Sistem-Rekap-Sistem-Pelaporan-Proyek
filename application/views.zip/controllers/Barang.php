<?php

class Barang extends CI_Controller
{
  public function index()
  {
    $this->load->view("barang/index");
  }
}
